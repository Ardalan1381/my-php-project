<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo '<p class="text-red-600">لطفاً وارد شوید!</p>';
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT amount, transaction_type, description, transaction_date 
                      FROM Wallet_Transactions 
                      WHERE user_id = :user_id 
                      ORDER BY transaction_date DESC");
$stmt->execute(['user_id' => $user_id]);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// تابع برای انتخاب آیکون و ترجمه نوع تراکنش
function getTransactionDetails($type) {
    switch ($type) {
        case 'DEPOSIT':
            return ['icon' => 'fa-arrow-down', 'label' => 'واریز'];
        case 'WITHDRAW':
            return ['icon' => 'fa-arrow-up', 'label' => 'برداشت'];
        case 'BOOKING':
            return ['icon' => 'fa-hotel', 'label' => 'رزرو'];
        case 'REDEEM':
            return ['icon' => 'fa-gift', 'label' => 'کد تخفیف'];
        case 'REFUND':
            return ['icon' => 'fa-undo', 'label' => 'عودت'];
        default:
            return ['icon' => 'fa-exchange-alt', 'label' => $type];
    }
}
?>
<div class="space-y-6 px-4 sm:px-6 lg:px-8">
    <?php if (empty($transactions)): ?>
        <div class="text-center p-6 bg-gray-100 rounded-xl shadow-md">
            <i class="fas fa-wallet text-gray-400 text-3xl sm:text-4xl mb-4"></i>
            <p class="text-gray-600 text-base sm:text-lg">هنوز تراکنشی ندارید!</p>
            <p class="text-sm text-gray-500 mt-2">با رزرو یا استفاده از کد تخفیف شروع کنید.</p>
        </div>
    <?php else: ?>
        <?php foreach ($transactions as $transaction): ?>
            <?php $details = getTransactionDetails($transaction['transaction_type']); ?>
            <div class="bg-white p-4 sm:p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between space-y-4 sm:space-y-0">
                    <div class="flex items-center space-x-4">
                        <i class="fas <?php echo $details['icon']; ?> text-blue-600 text-xl sm:text-2xl"></i>
                        <div>
                            <p class="text-gray-800 font-semibold text-base sm:text-lg"><?php echo htmlspecialchars($transaction['description']); ?></p>
                            <p class="text-gray-600 text-xs sm:text-sm"><?php echo htmlspecialchars($transaction['transaction_date']); ?></p>
                            <p class="text-gray-500 text-xs sm:text-sm"><?php echo $details['label']; ?></p>
                        </div>
                    </div>
                    <div class="text-left sm:text-right">
                        <?php $amount_class = $transaction['amount'] >= 0 ? 'text-green-600' : 'text-red-600'; ?>
                        <p class="<?php echo $amount_class; ?> font-semibold text-base sm:text-lg"><?php echo number_format($transaction['amount']) . ' تومان'; ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>