<?php
require_once __DIR__ . '/includes/db.php';
$page_title = "پروفایل - آستور";
include __DIR__ . '/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /site/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user = $db->prepare("SELECT `F-Name`, `L-Name`, Phone, address, video_path, verification_status FROM Users WHERE user_id = :user_id");
$user->execute(['user_id' => $user_id]);
$user = $user->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = filter_input(INPUT_POST, 'fname', FILTER_SANITIZE_STRING);
    $lname = filter_input(INPUT_POST, 'lname', FILTER_SANITIZE_STRING);
    $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
    $video = $_FILES['video'] ?? null;

    $updates = ['fname' => $fname, 'lname' => $lname, 'address' => $address, 'user_id' => $user_id];
    if ($video && $video['error'] == UPLOAD_ERR_OK) {
        $video_name = uniqid() . '.mp4';
        $video_path = __DIR__ . '/uploads/videos/' . $video_name;
        if (!is_dir(__DIR__ . '/uploads/videos')) mkdir(__DIR__ . '/uploads/videos', 0777, true);
        if (move_uploaded_file($video['tmp_name'], $video_path)) {
            $updates['video_path'] = '/site/uploads/videos/' . $video_name;
        } else {
            $error = "خطا در آپلود ویدیو!";
        }
    }

    if (!isset($error)) {
        $sql = "UPDATE Users SET `F-Name` = :fname, `L-Name` = :lname, address = :address" . (isset($updates['video_path']) ? ", video_path = :video_path" : "") . " WHERE user_id = :user_id";
        $stmt = $db->prepare($sql);
        $stmt->execute($updates);
        $success = "پروفایل با موفقیت به‌روزرسانی شد!";
        $user = array_merge($user, array_filter($updates, fn($key) => $key != 'user_id', ARRAY_FILTER_USE_KEY));
    }
}
?>
<main class="container mx-auto p-6">
    <?php if (isset($success)): ?>
        <p class="text-green-600 bg-green-100 p-4 rounded-lg mb-6"><?php echo $success; ?></p>
    <?php elseif (isset($error)): ?>
        <p class="text-red-600 bg-red-100 p-4 rounded-lg mb-6"><?php echo $error; ?></p>
    <?php elseif ($user['verification_status'] == 'Not Verified'): ?>
        <p class="text-yellow-600 bg-yellow-100 p-4 rounded-lg mb-6">لطفاً ویدیوی احراز هویت خود را آپلود کنید.</p>
    <?php endif; ?>
    <div class="bg-white p-8 rounded-lg shadow-md max-w-md mx-auto">
        <h2 class="text-2xl font-semibold text-blue-900 mb-6">پروفایل شما</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">نام</label>
                <input type="text" name="fname" value="<?php echo htmlspecialchars($user['F-Name']); ?>" class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">نام خانوادگی</label>
                <input type="text" name="lname" value="<?php echo htmlspecialchars($user['L-Name']); ?>" class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">شماره تلفن</label>
                <input type="text" value="<?php echo '0' . htmlspecialchars($user['Phone']); ?>" class="w-full p-3 border rounded-lg bg-gray-100" readonly>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">آدرس</label>
                <textarea name="address" class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
            </div>
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">ویدیوی احراز هویت</label>
                <?php if ($user['video_path']): ?>
                    <video controls class="w-full mb-2 rounded-lg">
                        <source src="<?php echo htmlspecialchars($user['video_path']); ?>" type="video/mp4">
                    </video>
                <?php endif; ?>
                <input type="file" name="video" accept="video/mp4" class="w-full p-3 border rounded-lg">
            </div>
            <button type="submit" class="btn bg-blue-600 text-white px-6 py-3 rounded-lg w-full"><i class="fas fa-save"></i> ذخیره</button>
        </form>
    </div>
</main>
<?php include __DIR__ . '/footer.php'; ?>