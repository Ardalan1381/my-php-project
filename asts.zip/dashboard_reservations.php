<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo '<p class="text-red-600">لطفاً وارد شوید!</p>';
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT `F-Name`, `L-Name` FROM Users WHERE user_id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// رزروهای هتل
$stmt = $db->prepare("SELECT r.id, h.hotel_name AS name, r.check_in_date, r.check_out_date, r.total_price, 'Hotel' AS type 
                      FROM Reservations r 
                      JOIN Hotels h ON r.hotel_id = h.hotel_id 
                      WHERE r.guest_name = :guest_name");
$stmt->execute(['guest_name' => $user['F-Name'] . ' ' . $user['L-Name']]);
$hotel_reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// رزروهای پزشک
$stmt = $db->prepare("SELECT mr.medical_reservation_id AS id, d.name, mr.appointment_date AS check_in_date, NULL AS check_out_date, mr.total_price, 'Doctor' AS type 
                      FROM Medical_Reservations mr 
                      JOIN Doctors d ON mr.doctor_id = d.doctor_id 
                      WHERE mr.user_id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$doctor_reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// رزروهای بیمارستان
$stmt = $db->prepare("SELECT hr.hospital_reservation_id AS id, h.name, hr.created_at AS check_in_date, NULL AS check_out_date, hr.total_price, 'Hospital' AS type 
                      FROM Hospital_Reservations hr 
                      JOIN Hospitals h ON hr.hospital_id = h.hospital_id 
                      WHERE hr.user_id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$hospital_reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ترکیب رزروها
$reservations = array_merge($hotel_reservations, $doctor_reservations, $hospital_reservations);
usort($reservations, function($a, $b) {
    return strtotime($b['check_in_date']) - strtotime($a['check_in_date']);
});
?>
<div class="space-y-6 px-4 sm:px-6 lg:px-8">
    <?php if (empty($reservations)): ?>
        <div class="text-center p-6 bg-gray-100 rounded-xl shadow-md">
            <i class="fas fa-hotel text-gray-400 text-3xl sm:text-4xl mb-4"></i>
            <p class="text-gray-600 text-base sm:text-lg">هنوز رزروی ندارید!</p>
            <a href="/site/book.php" class="mt-4 inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm sm:text-base">رزرو کنید</a>
        </div>
    <?php else: ?>
        <?php foreach ($reservations as $reservation): ?>
            <div class="bg-white p-4 sm:p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between space-y-4 sm:space-y-0">
                    <div class="flex items-center space-x-4">
                        <i class="fas <?php echo $reservation['type'] == 'Hotel' ? 'fa-hotel' : ($reservation['type'] == 'Doctor' ? 'fa-stethoscope' : 'fa-hospital'); ?> text-blue-600 text-xl sm:text-2xl"></i>
                        <div>
                            <h3 class="text-lg sm:text-xl font-semibold text-blue-900"><?php echo htmlspecialchars($reservation['name']); ?></h3>
                            <?php if ($reservation['type'] == 'Hotel'): ?>
                                <p class="text-gray-600 text-sm sm:text-base"><strong class="hidden sm:inline">ورود:</strong> <?php echo htmlspecialchars($reservation['check_in_date']); ?></p>
                                <p class="text-gray-600 text-sm sm:text-base"><strong class="hidden sm:inline">خروج:</strong> <?php echo htmlspecialchars($reservation['check_out_date']); ?></p>
                            <?php elseif ($reservation['type'] == 'Doctor'): ?>
                                <p class="text-gray-600 text-sm sm:text-base"><strong class="hidden sm:inline">تاریخ نوبت:</strong> <?php echo htmlspecialchars($reservation['check_in_date']); ?></p>
                            <?php else: ?>
                                <p class="text-gray-600 text-sm sm:text-base"><strong class="hidden sm:inline">تاریخ رزرو:</strong> <?php echo htmlspecialchars($reservation['check_in_date']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="text-left sm:text-right">
                        <p class="text-green-600 font-semibold text-base sm:text-lg"><?php echo number_format($reservation['total_price']) . ' تومان'; ?></p>
                        <span class="text-xs sm:text-sm text-gray-500">شناسه: <?php echo htmlspecialchars($reservation['id']); ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>