<footer class="bg-gray-800 text-white p-6 mt-8">
    <div class="container mx-auto text-center">
        <p>© 2025 آستور - تمامی حقوق محفوظ است.</p>
        <div class="mt-2">
            <a href="/site/about.php" class="mx-2 hover:text-blue-200">درباره ما</a>
            <a href="/site/contact.php" class="mx-2 hover:text-blue-200">تماس با ما</a>
            <a href="#" class="mx-2 hover:text-blue-200">قوانین</a>
        </div>
    </div>
</footer>
</body>
</html>