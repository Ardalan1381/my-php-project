<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// چک کردن وضعیت کاربر
$user_logged_in = isset($_SESSION['user_id']);
if ($user_logged_in) {
    $stmt = $db->prepare("SELECT `F-Name` FROM Users WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> | آستور</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">
    <header class="bg-white shadow-lg sticky top-0 z-50">
        <div class="container mx-auto px-6 py-4 flex items-center justify-between">
            <!-- لوگو -->
            <a href="/site/index.php" class="flex items-center space-x-3 transform hover:scale-105 transition-all duration-300">
                <i class="fas fa-hotel text-blue-600 text-3xl"></i>
                <span class="text-2xl font-bold text-blue-900">آستور</span>
            </a>

            <!-- منوی اصلی (دسکتاپ) -->
            <nav class="hidden md:flex items-center space-x-8">
                <a href="/site/index.php" class="text-gray-700 hover:text-blue-600 font-medium transition-colors duration-250 ml-6">خانه</a>
<a href="/site/hotels.php" class="text-gray-700 hover:text-blue-600 font-medium transition-colors duration-250">هتل‌ها</a>
                <a href="/site/about.php" class="text-gray-700 hover:text-blue-600 font-medium transition-colors duration-250">درباره ما</a>
                <?php if ($user_logged_in): ?>
                    <div class="flex items-center space-x-8">
                        <span class="text-blue-600 font-medium"><?php echo htmlspecialchars($user['F-Name']); ?></span>
                        <a href="/site/dashboard.php" class="text-gray-700 hover:text-blue-600 transition-colors duration-250"><i class="fas fa-tachometer-alt mr-2"></i> داشبورد</a>
                        <a href="/site/logout.php" class="btn bg-red-500 text-white px-4 py-2 rounded-full hover:bg-red-600 transition-all duration-250"><i class="fas fa-sign-out-alt mr-2"></i> خروج</a>
                    </div>
                <?php else: ?>
                    <a href="/site/login.php" class="btn bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition-all duration-250"><i class="fas fa-sign-in-alt mr-2"></i> ورود</a>
                    <a href="/site/register.php" class="btn bg-blue-100 text-blue-900 px-4 py-2 rounded-full hover:bg-blue-200 transition-all duration-250"><i class="fas fa-user-plus mr-2"></i> ثبت‌نام</a>
                <?php endif; ?>
            </nav>

            <!-- دکمه منوی موبایل -->
            <button id="mobile-menu-btn" class="md:hidden text-gray-700 focus:outline-none">
                <i class="fas fa-bars text-2xl"></i>
            </button>
        </div>

        <!-- منوی موبایل -->
        <div id="mobile-menu" class="hidden md:hidden bg-white shadow-lg">
            <div class="px-6 py-6 space-y-6">
                <a href="/site/index.php" class="block text-gray-700 hover:text-blue-600 font-medium transition-colors duration-250">خانه</a>
                <a href="/site/hotels.php" class="block text-gray-700 hover:text-blue-600 font-medium transition-colors duration-250">هتل‌ها</a>
                <a href="/site/about.php" class="block text-gray-700 hover:text-blue-600 font-medium transition-colors duration-250">درباره ما</a>
                <?php if ($user_logged_in): ?>
                    <div class="border-t pt-4 space-y-6">
                        <span class="block text-blue-600 font-medium"><?php echo htmlspecialchars($user['F-Name']); ?></span>
                        <a href="/site/dashboard.php" class="block text-gray-700 hover:text-blue-600 transition-colors duration-250"><i class="fas fa-tachometer-alt mr-2"></i> داشبورد</a>
                        <a href="/site/logout.php" class="block text-red-600 hover:text-red-700 transition-colors duration-250"><i class="fas fa-sign-out-alt mr-2"></i> خروج</a>
                    </div>
                <?php else: ?>
                    <div class="border-t pt-4 space-y-6">
                        <a href="/site/login.php" class="block text-blue-600 hover:text-blue-700 transition-colors duration-250"><i class="fas fa-sign-in-alt mr-2"></i> ورود</a>
                        <a href="/site/register.php" class="block text-blue-600 hover:text-blue-700 transition-colors duration-250"><i class="fas fa-user-plus mr-2"></i> ثبت‌نام</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <script>
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    </script>
</body>