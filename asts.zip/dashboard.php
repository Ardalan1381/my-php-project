<?php
require_once __DIR__ . '/includes/db.php';
$page_title = "داشبورد - آستور";
include __DIR__ . '/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /site/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user = $db->prepare("SELECT `F-Name`, `L-Name`, Phone, balance, video_path, verification_status FROM Users WHERE user_id = :user_id");
$user->execute(['user_id' => $user_id]);
$user = $user->fetch(PDO::FETCH_ASSOC);

if ($user['verification_status'] == 'Rejected') {
    echo '<main class="container mx-auto px-4 sm:px-6 lg:px-8 py-6"><p class="text-red-600 bg-red-100 p-4 rounded-lg">حساب شما رد شده است. لطفاً با پشتیبانی تماس بگیرید: 021-12345678</p></main>';
    include __DIR__ . '/footer.php';
    exit;
} elseif ($user['verification_status'] == 'Not Verified') {
    header("Location: /site/profile.php");
    exit;
}

// Redeem Code
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['redeem_code'])) {
    $code = filter_input(INPUT_POST, 'redeem_code', FILTER_SANITIZE_STRING);
    $stmt = $db->prepare("SELECT code_id, amount FROM Redeem_Codes WHERE code = :code AND used_by IS NULL");
    $stmt->execute(['code' => $code]);
    $redeem = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($redeem) {
        $db->beginTransaction();
        try {
            $db->prepare("UPDATE Users SET balance = balance + :amount WHERE user_id = :user_id")
               ->execute(['amount' => $redeem['amount'], 'user_id' => $user_id]);
            $db->prepare("UPDATE Redeem_Codes SET used_by = :user_id, used_at = NOW() WHERE code_id = :code_id")
               ->execute(['user_id' => $user_id, 'code_id' => $redeem['code_id']]);
            $db->prepare("INSERT INTO Wallet_Transactions (user_id, amount, transaction_type, description) 
                          VALUES (:user_id, :amount, 'REDEEM', :description)")
               ->execute(['user_id' => $user_id, 'amount' => $redeem['amount'], 'description' => "استفاده از کد تخفیف $code"]);
            $db->commit();
            $success = "کد با موفقیت اعمال شد! مبلغ " . number_format($redeem['amount']) . " تومان به حساب شما اضافه شد.";
            $user['balance'] += $redeem['amount'];
        } catch (Exception $e) {
            $db->rollBack();
            $error = "خطایی رخ داد: " . $e->getMessage();
        }
    } else {
        $error = "کد نامعتبر است یا قبلاً استفاده شده!";
    }
}
?>
<main class="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
    <!-- هدر داشبورد -->
    <section class="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6 sm:p-8 rounded-xl shadow-lg mb-6">
        <h1 class="text-2xl sm:text-3xl font-bold animate-fade-in"><?php echo htmlspecialchars($user['F-Name']); ?> خوش آمدید!</h1>
        <p class="text-base sm:text-lg mt-2">اینجا همه‌چیز برای مدیریت حساب شماست.</p>
    </section>

    <!-- اعلان‌ها -->
    <?php if (isset($success)): ?>
        <p class="text-green-600 bg-green-100 p-4 rounded-lg mb-6 flex items-center text-sm sm:text-base"><i class="fas fa-check-circle mr-2"></i> <?php echo $success; ?></p>
    <?php elseif (isset($error)): ?>
        <p class="text-red-600 bg-red-100 p-4 rounded-lg mb-6 flex items-center text-sm sm:text-base"><i class="fas fa-exclamation-circle mr-2"></i> <?php echo $error; ?></p>
    <?php endif; ?>

    <!-- اطلاعات کاربر -->
    <div class="bg-white p-6 sm:p-8 rounded-xl shadow-md mb-6 border border-gray-100">
        <h2 class="text-xl sm:text-2xl font-semibold text-blue-900 mb-4"><i class="fas fa-user-circle mr-2"></i> اطلاعات حساب</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            <p class="text-sm sm:text-base"><span class="font-medium text-gray-700">نام:</span> <?php echo htmlspecialchars($user['F-Name']); ?></p>
            <p class="text-sm sm:text-base"><span class="font-medium text-gray-700">نام خانوادگی:</span> <?php echo htmlspecialchars($user['L-Name']); ?></p>
            <p class="text-sm sm:text-base"><span class="font-medium text-gray-700">شماره تلفن:</span> <?php echo '0' . htmlspecialchars($user['Phone']); ?></p>
            <p class="text-sm sm:text-base"><span class="font-medium text-gray-700">موجودی:</span> <span class="text-green-600"><?php echo number_format($user['balance'], 2); ?> تومان</span></p>
            <p class="text-sm sm:text-base"><span class="font-medium text-gray-700">وضعیت:</span> <span class="text-green-600">تأیید شده</span></p>
        </div>
        <a href="/site/profile.php" class="mt-4 inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm sm:text-base"><i class="fas fa-edit mr-2"></i> ویرایش پروفایل</a>
    </div>

    <!-- کد تخفیف -->
    <div class="bg-white p-6 sm:p-8 rounded-xl shadow-md mb-6 border border-gray-100">
        <h2 class="text-xl sm:text-2xl font-semibold text-blue-900 mb-4"><i class="fas fa-gift mr-2"></i> شارژ کیف پول</h2>
        <form method="POST" class="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <input type="text" name="redeem_code" class="w-full sm:w-2/3 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base" placeholder="کد تخفیف را وارد کنید" required>
            <button type="submit" class="w-full sm:w-auto bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition text-sm sm:text-base"><i class="fas fa-check mr-2"></i> اعمال</button>
        </form>
    </div>

    <!-- تاریخچه -->
    <div class="bg-white p-6 sm:p-8 rounded-xl shadow-md border border-gray-100">
        <h2 class="text-xl sm:text-2xl font-semibold text-blue-900 mb-4"><i class="fas fa-history mr-2"></i> تاریخچه</h2>
        <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mb-6">
            <button onclick="loadSection('reservations')" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm sm:text-base"><i class="fas fa-hotel mr-2"></i> رزروها</button>
            <button onclick="loadSection('transactions')" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm sm:text-base"><i class="fas fa-wallet mr-2"></i> تراکنش‌ها</button>
        </div>
        <div id="section-content" class="mt-4 p-4 bg-gray-50 rounded-lg"></div>
    </div>
</main>
<script>
function loadSection(section) {
    fetch(`/site/dashboard_${section}.php?ts=${new Date().getTime()}`)
        .then(response => response.text())
        .then(data => document.getElementById('section-content').innerHTML = data)
        .catch(error => document.getElementById('section-content').innerHTML = '<p class="text-red-600">خطا: ' + error + '</p>');
}
</script>
<style>
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .animate-fade-in { animation: fadeIn 1s ease-in; }
</style>
<?php include __DIR__ . '/footer.php'; ?>