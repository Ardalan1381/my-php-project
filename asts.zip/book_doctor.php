<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/includes/db.php';
$page_title = "رزرو نوبت پزشک - آستور";
include __DIR__ . '/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /site/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT balance FROM Users WHERE user_id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$success_message = '';
$error_message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['book_doctor'])) {
    $doctor_id = filter_input(INPUT_POST, 'doctor_id', FILTER_VALIDATE_INT);
    $appointment_date = filter_input(INPUT_POST, 'appointment_date', FILTER_SANITIZE_STRING);

    if ($doctor_id && $appointment_date) {
        // گرفتن اطلاعات پزشک
        $stmt = $db->prepare("SELECT fee FROM Doctors WHERE doctor_id = :doctor_id");
        $stmt->execute(['doctor_id' => $doctor_id]);
        $doctor = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($doctor) {
            $total_price = $doctor['fee'];

            // چک کردن موجودی
            if ($user['balance'] < $total_price) {
                $error_message = "موجودی کافی نیست!";
            } else {
                // چک کردن رزروهای قبلی برای محدودیت نیم ساعت
                $start_time = strtotime($appointment_date);
                $end_time = $start_time + (30 * 60); // نیم ساعت بعد
                $stmt = $db->prepare("SELECT COUNT(*) FROM Medical_Reservations 
                                      WHERE doctor_id = :doctor_id 
                                      AND appointment_date BETWEEN :start_time AND :end_time");
                $stmt->execute([
                    'doctor_id' => $doctor_id,
                    'start_time' => date('Y-m-d H:i:s', $start_time - (30 * 60)), // نیم ساعت قبل
                    'end_time' => date('Y-m-d H:i:s', $end_time)
                ]);
                $conflict = $stmt->fetchColumn();

                if ($conflict > 0) {
                    $error_message = "این ساعت رزرو شده یا با رزرو دیگری تداخل دارد! حداقل نیم ساعت فاصله لازم است.";
                } else {
                    $db->beginTransaction();
                    try {
                        $stmt = $db->prepare("INSERT INTO Medical_Reservations (user_id, doctor_id, appointment_date, total_price) 
                                              VALUES (:user_id, :doctor_id, :appointment_date, :total_price)");
                        $stmt->execute([
                            'user_id' => $user_id,
                            'doctor_id' => $doctor_id,
                            'appointment_date' => $appointment_date,
                            'total_price' => $total_price
                        ]);
                        $db->prepare("UPDATE Users SET balance = balance - :total_price WHERE user_id = :user_id")
                           ->execute(['total_price' => $total_price, 'user_id' => $user_id]);
                        $db->prepare("INSERT INTO Wallet_Transactions (user_id, amount, transaction_type, description) 
                                      VALUES (:user_id, :amount, 'BOOKING', :description)")
                           ->execute([
                               'user_id' => $user_id,
                               'amount' => -$total_price,
                               'description' => "رزرو نوبت پزشک - ID: $doctor_id"
                           ]);
                        $db->commit();
                        $success_message = "نوبت پزشک با موفقیت رزرو شد!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error_message = "خطا در رزرو: " . $e->getMessage();
                    }
                }
            }
        } else {
            $error_message = "پزشک یافت نشد!";
        }
    } else {
        $error_message = "لطفاً همه فیلدها را پر کنید!";
    }
}

$stmt = $db->prepare("SELECT doctor_id, name, specialty, availability, fee FROM Doctors");
$stmt->execute();
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<main class="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
    <h1 class="text-2xl sm:text-3xl font-bold text-blue-900 mb-6">رزرو نوبت پزشک</h1>
    
    <?php if ($success_message): ?>
        <p class="text-green-600 bg-green-100 p-4 rounded-lg mb-6 flex items-center text-sm sm:text-base"><i class="fas fa-check-circle mr-2"></i> <?php echo $success_message; ?></p>
    <?php elseif ($error_message): ?>
        <p class="text-red-600 bg-red-100 p-4 rounded-lg mb-6 flex items-center text-sm sm:text-base"><i class="fas fa-exclamation-circle mr-2"></i> <?php echo $error_message; ?></p>
    <?php endif; ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($doctors as $doctor): ?>
            <div class="bg-white p-4 sm:p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-stethoscope text-blue-600 text-xl sm:text-2xl"></i>
                    <div>
                        <h3 class="text-lg sm:text-xl font-semibold text-blue-900"><?php echo htmlspecialchars($doctor['name']); ?></h3>
                        <p class="text-gray-600 text-sm sm:text-base">تخصص: <?php echo htmlspecialchars($doctor['specialty']); ?></p>
                        <p class="text-gray-600 text-sm sm:text-base">دسترسی: <?php echo htmlspecialchars($doctor['availability']); ?></p>
                        <p class="text-green-600 font-semibold text-base sm:text-lg"><?php echo number_format($doctor['fee']) . ' تومان'; ?></p>
                    </div>
                </div>
                <form method="POST" class="mt-4 flex flex-col space-y-4">
                    <input type="hidden" name="doctor_id" value="<?php echo $doctor['doctor_id']; ?>">
                    <input type="datetime-local" name="appointment_date" class="p-2 border rounded-lg text-sm sm:text-base" required>
                    <button type="submit" name="book_doctor" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm sm:text-base">رزرو نوبت</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</main>
<?php include __DIR__ . '/footer.php'; ?>