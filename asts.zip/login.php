<?php
require_once __DIR__ . '/includes/db.php';
$page_title = "ورود - آستور";
include __DIR__ . '/header.php';

if (isset($_SESSION['user_id'])) {
    header("Location: /site/dashboard.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $identifier = filter_input(INPUT_POST, 'identifier', FILTER_SANITIZE_STRING); // نام کاربری یا ایمیل
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

    $stmt = $db->prepare("SELECT user_id, password FROM Users WHERE username = :identifier OR email = :identifier");
    $stmt->execute(['identifier' => $identifier]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        header("Location: /site/dashboard.php");
        exit;
    } else {
        $error = "نام کاربری/ایمیل یا رمز عبور اشتباه است!";
    }
}
?>
<main class="container mx-auto p-6">
    <div class="bg-white p-8 rounded-lg shadow-md max-w-md mx-auto">
        <h2 class="text-2xl font-semibold text-blue-900 mb-6">ورود</h2>
        <?php if (isset($error)): ?>
            <p class="text-red-600 bg-red-100 p-4 rounded-lg mb-6"><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">نام کاربری یا ایمیل</label>
                <input type="text" name="identifier" class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">رمز عبور</label>
                <input type="password" name="password" class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            <button type="submit" class="btn bg-blue-600 text-white px-6 py-3 rounded-lg w-full hover:bg-blue-700 transition"><i class="fas fa-sign-in-alt"></i> ورود</button>
        </form>
        <p class="mt-4 text-center">حساب ندارید؟ <a href="/site/register.php" class="text-blue-600 hover:underline">ثبت‌نام کنید</a></p>
    </div>
</main>
<?php include __DIR__ . '/footer.php'; ?>